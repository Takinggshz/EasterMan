map_1 = {
    'terrain':'code/one/Level_1_Grass.csv',
    'coin' : 'code/one/Level_1_coin.csv',
    'trees':'code/one/Level_1_Tree.csv',
    'Egg':'code/one/Level_1_EGG.csv',
}